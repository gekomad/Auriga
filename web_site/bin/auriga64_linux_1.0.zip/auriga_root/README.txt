Welcome to AURIGA - Distribuite and Collaborative Perft System

This is the auriga_root directory

Author: Giuseppe Cannella - 2015
Home: http://auriga-cinnamon.rhcloud.com

Install Binary
==============
Copy the auriga_root folder somewhere in your file system and set the environment variable AURIGA_ROOT whith full path

Use GLIBCXX_3.4.21
==============
Auriga uses GLIB.6.21 if error occurs "version `GLIBCXX_3.4.21' not found (required by ./auriga)" run auriga with
export LD_LIBRARY_PATH=$AURIGA_ROOT;$AURIGA_ROOT/auriga
or build yourself auriga

Building AURIGA
===============

Linux/Windows/ARM/Mac
-----
Required c++11 compiler (g++ 4.9, clang++ 3.3.0)
download source from https://github.com/gekomad/Auriga
and type make in src folder

copy binary inside auriga_root and set the environment variable AURIGA_ROOT with full path

------
view http://auriga-cinnamon.rhcloud.com for more info
