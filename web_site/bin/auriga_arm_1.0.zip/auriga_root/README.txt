This is the auriga_root directory

copy the folder somewhere in your file system and set the environment variable AURIGA_ROOT with full path

if auriga exit with this error: `GLIBCXX_3.4.20' not found
add
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$AURIGA_ROOT

view http://auriga-cinnamon.rhcloud.com for more info



