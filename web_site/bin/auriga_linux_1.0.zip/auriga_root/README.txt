This is the auriga_root directory

Copy the folder somewhere in your file system and set the environment variable AURIGA_ROOT with full path

You could compile yourself auriga cloning it from https://github.com/gekomad/Auriga

If auriga exits with the error: `GLIBCXX_3.4.21' not found
add type export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$AURIGA_ROOT and rerun auriga

View http://auriga-cinnamon.rhcloud.com for more info

For 32 bit system rename 'auriga32' in 'auriga'

