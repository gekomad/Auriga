This is the auriga_root directory

copy the folder somewhere in your file system and set the environment variable AURIGA_ROOT whith full path

view http://auriga-cinnamon.rhcloud.com for more info


for 32 bit system rename auriga32.exe in auriga.exe

